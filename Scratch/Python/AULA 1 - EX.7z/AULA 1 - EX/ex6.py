#-*- coding: UTF-8 -*-

print("Calcular o tempo de viagem!")

distancia = float(input("digite a distância da viagem: "))


velo_med = float(input("digite a velocidade média: "))

tempo_viagem = distancia / velo_med

print("O tempo a percorrer em horas é de: ", tempo_viagem)
