#-*- coding:UTF-8 -*-

print("Digite dois valores e eu trarei a soma")

num = int(input("Digite o primeiro valor: "))

num2 = int(input("Digite o segundo valor: "))

soma = num + num2

print("A soma dos valores é: ", soma)
