#-*- coding: UTF-8 -*-

print("Vou converter de metros para milímetros")

metros = int(input("Digite o valor em metros: "))

milimet = metros * 1000

print("O resultado é: ", milimet)
