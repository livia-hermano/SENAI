#-*- coding: UTF-8 -*-
"""
7) Escreva um programa que converta uma temperatura digitada em oC para oF. A fórmula para essa conversão é:
F = 9 / 5 x C + 32 

"""
print("Vamos converter temperaturas!")

c = float(input("Digite a temperatura em Celcius: "))

f = 9 / 5 * c + 32

print("A conversão de Celsius para Fairenhigth é de: ",f)


