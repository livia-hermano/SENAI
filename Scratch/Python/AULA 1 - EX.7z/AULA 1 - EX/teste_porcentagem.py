#-*- coding: UTF-8 -*-

print("me fala seu nome e idade")

nome = input("Digite o nome: ")

idade = int(input("digite a idade: "))

print("Oi %s tudo bem? Legal você tem %i anos" %(nome, idade))
