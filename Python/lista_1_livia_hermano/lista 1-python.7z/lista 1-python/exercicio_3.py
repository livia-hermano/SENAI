#-*- coding: UTF-8-*-
print ('Me diga dois números inteiros e lhe direi qual o maior entre eles.')
num1= int(input('Digite o primeiro número:'))
num2= int(input('Digite o segundo valor:'))
if num1>num2:
    print ('O', num1,'é maior que', num2)
    
else:
    print ('O', num2, 'é maior que', num1)
