#-*- coding: UTF-8-*-
print('Me diga um número e lhe direi se ele é múltiplo de 3.')
num= float(input('Digite o número aqui:'))
if num%3==0:
    print('O número é múltiplo de 3')

else:
    print('O número não é múltiplo de 3')
