# -*- coding: UTF-8 -*-

print('Olá, irei lhe mostrar números de 1 a 50, e também a sua ordem inversa (50 ao 1)')

for i in range (1,51):
    print(i)
for v in range (50,0,-1):
    print(v)
