# -*- coding: UTF-8 -*-

print('Direi a tabuada do 0 ao 9 para você.')
for tabuada in range (0,10):
    for calculo in range (1,11):
        print(tabuada,'*', calculo,'=', tabuada * calculo)
