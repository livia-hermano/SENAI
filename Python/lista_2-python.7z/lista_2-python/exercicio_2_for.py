# -*- coding: UTF-8 -*-
print('Irei mostrar a soma dos primeiros 50 números pares.')
soma=0
for i in range (0,101,2):
     soma=soma+i

print('A soma dos números pares é', soma)
