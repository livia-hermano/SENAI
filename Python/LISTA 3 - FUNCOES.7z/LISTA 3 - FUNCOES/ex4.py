#Ex4 - funções

print("Digite o valor de contagem e lhe darei a contagem regressiva: IHAA")

valor_contagem = int(input("Qual o valor: "))


def contagem_regressiva():
    global valor_contagem
    for celso in range(valor_contagem, -1, -1):
        print("Vamos contar: ",celso)
    print("EEEEEEEEEEEEE feliz FÉRIAS")


contagem_regressiva()
