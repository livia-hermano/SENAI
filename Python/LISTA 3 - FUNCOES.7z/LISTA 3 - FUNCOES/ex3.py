#Ex3 - FUNÇÕES

print("usuário, você vai digitar um número e trarei a tabuada deste número(1 a 10)")

def tabuada(numero):
    for daniel in range(0, 11):
        print(f"{numero} * {daniel} = {daniel*numero}")



valor = int(input("Digite um valor para a tabuada"))

tabuada(valor)
