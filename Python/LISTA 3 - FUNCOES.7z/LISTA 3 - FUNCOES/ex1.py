#Número 1 - LISTA FUNÇÕES
import math
print("Esse programa fará o cálculo do volume!")

def calc_volume ():
    raio = float(input("Digite o raio: "))
    altura = float(input("Digite a altura: "))
    volume = math.pi * raio ** 2 * altura

    #print(f"A quantidade do volume é: {volume:.2f}")
    #print("A quantidade de volum é: %.2f " %volume)
    return volume


#calc_volume()
print(f"A quantidade de volume é: {calc_volume():.2f}")
