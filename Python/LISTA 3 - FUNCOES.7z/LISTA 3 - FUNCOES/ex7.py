#Ex 7 - FUNÇÕES

print("Vamos executar uma calculadora!")

def soma(num1,num2):
    print("A soma dos valores é: ", num1+num2)
    

def subtracao(num1,num2):
    print("A subtração dos valores é: ", num1 - num2)


def multiplicacao(num1,num2):
    print("A multiplicação dos valores é: ", num1 * num2)



def divisao(num1,num2):
    print("A divisão dos valores é: ", num1 / num2)

valor1 = int(input("Digite o primeiro valor: "))

valor2 = int(input("Digite o segundo valor: "))

op = input("Digite uma das operações: + - * /")

if op == "+":
    soma(valor1,valor2)
elif op == "-":
    subtracao(valor1,valor2)
elif op == "*":
    multiplicacao(valor1,valor2)
elif op == "/":
    divisao(valor1,valor2)
else:
    print("Você digitou um valor inexistente, favor digitar novamente!")












