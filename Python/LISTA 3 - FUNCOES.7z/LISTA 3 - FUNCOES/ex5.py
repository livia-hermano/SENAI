#Ex5 - Funções

print("Vamos calcular o valor digitado para verificar se é primo ou não!")


def num_primos():
    num = int(input("Digite um valor para começarmos: "))

    for marlon in range(2, num):
        if num % marlon == 0:
            return "NÃO é primo"
        else:
            return "É primo"

print(num_primos())


            
