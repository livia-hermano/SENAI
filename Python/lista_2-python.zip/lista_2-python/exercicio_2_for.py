# -*- coding: UTF-8 -*-
print('Irei mostrar a soma dos números pares de 0 a 50.')
soma=0
for i in range (0,51):
     soma+= 2*i

print('A soma dos números pares é', soma)
