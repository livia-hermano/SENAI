#-*- coding: UTF-8-*-
print ('Me diga um número e lhe direi se é par ou ímpar')
num= int(input('Digite o número:'))
if num %2==0:
    print('O número é par.')
else:
    print ('O número é ímpar.')
